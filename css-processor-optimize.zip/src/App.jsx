import React, { useState } from "react";
import PapaWorkerReader from "./readers/PapaWorkerReader";

export default function App() {
  const [files, setFiles] = useState([]);

  return (
    <div style={{ padding: 20 }}>
      <h1>Large File Validator (Worker + Virtual Table)</h1>

      <input
        type="file"
        accept=".csv"
        multiple
        onChange={(e) => setFiles([...e.target.files])}
      />

       {files.length > 0 &&
        files.map((file, idx) => (
          <PapaWorkerReader key={idx} file={file} />
        ))}  

    </div>
  );
}
