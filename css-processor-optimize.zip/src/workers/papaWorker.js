const Papa = {
  parse(file, config) {
    const reader = new FileReader();

    reader.onload = () => {
      const text = reader.result;
      const lines = text.split(/\r?\n/);
      const headers = lines[0].split(",");

      let batch = [];
      let processed = 0;
      const totalGuess = 500000;

      for (let i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;

        const cols = lines[i].split(",");
        const row = {};
        headers.forEach((h, idx) => (row[h] = cols[idx] || ""));

        batch.push(row);
        processed++;

        if (batch.length >= 5000) {
          config.chunk({ data: batch });
          batch = [];
          const pct = Math.min(100, Math.round((processed / totalGuess) * 100));
          self.postMessage({ progress: pct });
        }
      }

      if (batch.length) config.chunk({ data: batch });

      config.complete();
      self.postMessage({ rows: lines.length > 1 ? lines.slice(1).map((l) => {
        const cols = l.split(",");
        const obj = {};
        headers.forEach((h, i) => (obj[h] = cols[i] || ""));
        return obj;
      }) : [] });
    };

    reader.readAsText(file);
  },
};

self.onmessage = (e) => {
  Papa.parse(e.data.file, {
    header: true,
    skipEmptyLines: true,
    chunk: () => {},
    complete: () => {},
  });
};
