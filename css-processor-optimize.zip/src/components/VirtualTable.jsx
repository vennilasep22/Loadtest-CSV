import React from "react";
import { FixedSizeList as List } from "react-window";

export default function VirtualTable({ rows, rowErrors, onRowClick }) {
  const keys = rows.length ? Object.keys(rows[0]) : [];

  const Row = ({ index, style }) => {
    const row = rows[index];
    console.log('row:',row);
    
    const hasError = rowErrors[index];

    return (
      <div
        onClick={() => onRowClick(row)}
        style={{
          ...style,
          display: "flex",
          padding: "4px",
          background: hasError ? "#ffd6d6" : "white",
          cursor: "pointer",
          borderBottom: "1px solid #eee",
        }}
      >
        {keys.map((k, i) => (
          <div key={i} style={{ width: 200, padding: "0 8px" }}>
            {row[k]}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div>
      <div style={{ display: "flex", background: "#333", color: "#fff", padding: 6 }}>
        {keys.map((k, i) => (
          <div key={i} style={{ width: 200, padding: "0 8px" }}>{k}</div>
        ))}
      </div>

      <List height={500} itemCount={rows.length} itemSize={35} width="100%">
        {Row}
      </List>
    </div>
  );
}
