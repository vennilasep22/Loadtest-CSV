export default function HeaderError({ errors }) {
  return (
    <div style={{ background: "#ffe1e1", padding: 10, border: "1px solid red" }}>
      <h3>❌ Invalid Header</h3>
      {errors.missing && <p>Missing: {errors.missing.join(", ")}</p>}
      {errors.extra && <p>Extra: {errors.extra.join(", ")}</p>}
      {errors.order && <p>Order mismatch</p>}
    </div>
  );
}
