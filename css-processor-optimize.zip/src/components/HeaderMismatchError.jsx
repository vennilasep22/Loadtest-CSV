export default function HeaderMismatchError({ error }) {
  return (
    <div style={{ background: "#ffe1e1", padding: 10, border: "1px solid red" }}>
      <h3>❌ Header Mismatch Across Files</h3>

      <p>File: <b>{error.file}</b></p>

      <p>Expected:</p>
      <pre>{JSON.stringify(error.expected, null, 2)}</pre>

      <p>Received:</p>
      <pre>{JSON.stringify(error.received, null, 2)}</pre>
    </div>
  );
}
