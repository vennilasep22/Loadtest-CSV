// export default function ProgressBar({ progress }) {
//   return (
//     <div style={{ margin: "10px 0" }}>
//       <div
//         style={{
//           height: 10,
//           background: "#ddd",
//           borderRadius: 5,
//         }}
//       >
//         <div
//           style={{
//             width: `${progress}%`,
//             height: 10,
//             background: "green",
//           }}
//         />
//       </div>
//       <p>{progress}%</p>
//     </div>
//   );
// }
export default function ProgressBar({ progress }) {
  return (
    <div style={{ marginTop: 10 }}>
      <div
        style={{
          width: "100%",
          height: 8,
          background: "#eee",
          borderRadius: 4
        }}
      >
        <div
          style={{
            width: `${progress}%`,
            height: "100%",
            background: "#4caf50",
            borderRadius: 4,
            transition: "0.2s"
          }}
        />
      </div>

      <div style={{ fontSize: 12, marginTop: 3 }}>{progress}%</div>
    </div>
  );
}
