export default function ErrorPanel({ rowErrors }) {
  const total = Object.keys(rowErrors).length;
  if (!total) return null;

  return (
    <div style={{
      margin: "10px 0",
      padding: 10,
      background: "#fff4e6",
      border: "1px solid #ffbf75",
      borderRadius: 6,
    }}>
      <strong>Error Rows: {total}</strong>
      <ul>
        {Object.entries(rowErrors).slice(0, 10).map(([i, err]) => (
          <li key={i}>
            Row {i}: {Object.values(err).join(", ")}
          </li>
        ))}
      </ul>
      {total > 10 && <em>...more errors hidden</em>}
    </div>
  );
}
