export default function RowDetailModal({ row, close }) {
  if (!row) return null;

  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.5)",
      display: "flex", justifyContent: "center", alignItems: "center"
    }}>
      <div style={{ background: "white", padding: 20, width: 400, borderRadius: 8 }}>
        <h3>Row Details</h3>
        <pre>{JSON.stringify(row, null, 2)}</pre>
        <button onClick={close}>Close</button>
      </div>
    </div>
  );
}
