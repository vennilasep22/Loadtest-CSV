import React from "react";

const ErrorPercentage = ({ total = 0, errors = 0 }) => {
  if (!total) return null;
  const pct = ((errors / total) * 100).toFixed(2);
  return (
    <div style={{ marginTop: 12, padding: 8, background: "#f0f7ff", border: "1px solid #cfe8ff", borderRadius: 6 }}>
      <strong>Error Percentage:</strong> {pct}% &nbsp; | &nbsp;
      <strong>Error Rows:</strong> {errors} &nbsp; | &nbsp;
      <strong>Total Rows:</strong> {total}
    </div>
  );
};

export default ErrorPercentage;
