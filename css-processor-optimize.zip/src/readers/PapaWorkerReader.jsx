import React, { useEffect, useState } from "react";
import VirtualTable from "../components/VirtualTable";
import ErrorPanel from "../components/ErrorPanel";
import RowDetailModal from "../components/RowDetailModal";
import { validateRow } from "../utils/validators";
import { exportErrors, exportValid } from "../utils/exporter";

export default function PapaWorkerReader({ file }) {
  const [progress, setProgress] = useState(0);
  const [eta, setEta] = useState("Calculating...");
  const [rows, setRows] = useState([]);
  const [rowErrors, setRowErrors] = useState({});
  const [selectedRow, setSelectedRow] = useState(null);
  const [startTime] = useState(Date.now());

  useEffect(() => {
    const worker = new Worker(new URL("../workers/papaWorker.js", import.meta.url));
    worker.postMessage({ file });

    worker.onmessage = (e) => {
      if (e.data.progress !== undefined) {
        const pct = e.data.progress;
        setProgress(pct);

        const elapsed = (Date.now() - startTime) / 1000;
        const total = elapsed / (pct / 100);
        const remaining = total - elapsed;

        setEta(`${remaining.toFixed(1)} sec`);
      }

      if (e.data.rows) {
        const parsed = e.data.rows;

        const errors = {};
        parsed.forEach((row, i) => {
          const err = validateRow(row);
          if (Object.keys(err).length) errors[i] = err;
        });

        setRowErrors(errors);
        setRows(parsed);
      }
    };

    return () => worker.terminate();
  }, [file]);

  return (
    <div style={{ marginTop: 20 }}>
      <h2>{file.name}</h2>
      <p>Progress: {progress}%</p>
      <p>ETA: {eta}</p>

      <RowDetailModal row={selectedRow} close={() => setSelectedRow(null)} />
         <ErrorPanel rowErrors={rowErrors} />

      <button onClick={() => exportErrors(rows, rowErrors)}>Export Errors</button>
      <button onClick={() => exportValid(rows, rowErrors)} style={{ marginLeft: 10 }}>
        Export Valid
      </button>
       <div style={{ marginTop: 20 }}></div>
      <VirtualTable
        rows={rows}
        rowErrors={rowErrors}
        onRowClick={(row) => setSelectedRow(row)}
      />
    </div>
  );
}
