export const validateRow = (row) => {
  const errors = {};

  // Required check
  Object.keys(row).forEach((col) => {
    if (!row[col] || row[col].trim() === "") {
      errors[col] = `${col} is required`;
    }
  });

  // Email format
  if (row.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(row.email)) {
      errors.email = "Invalid email format";
    }
  }

  // Age
  if (row.age) {
    const age = Number(row.age);
    if (isNaN(age) || age < 1 || age > 120) {
      errors.age = "Age must be between 1 and 120";
    }
  }

  // Phone (10 digits)
  if (row.phone) {
    const digits = row.phone.replace(/\D/g, "");
    if (digits.length !== 10) {
      errors.phone = "Phone must be 10 digits";
    }
  }

  return errors;
};
