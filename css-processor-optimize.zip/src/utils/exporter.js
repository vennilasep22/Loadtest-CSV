import Papa from "papaparse";
import { saveAs } from "file-saver";

export const exportErrors = (rows, rowErrors) => {
  const errorsOnly = Object.keys(rowErrors).map((i) => rows[i]);
  const csv = Papa.unparse(errorsOnly);
  saveAs(new Blob([csv], { type: "text/csv" }), "error_rows.csv");
};

export const exportValid = (rows, rowErrors) => {
  const valid = rows.filter((_, i) => !rowErrors[i]);
  const csv = Papa.unparse(valid);
  saveAs(new Blob([csv], { type: "text/csv" }), "valid_rows.csv");
};
