# CSV Strategies Demo

This demo implements multiple strategies for reading and validating very large local CSV files in the browser:

- PapaParse streaming + worker validation
- File.slice chunk reader (buffered)
- Native Streams API reader
- Manual parser in a Web Worker
- Virtualized table for display

## Quick start

```bash
npm install
npm run dev
# open http://localhost:5173
