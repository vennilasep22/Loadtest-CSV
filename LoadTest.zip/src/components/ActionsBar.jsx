import React from "react";
import { exportCSV } from "../utils/exportCSV";
import { exportErrorRows } from "../utils/exportErrorRows";

const ActionsBar = ({ fileData, errors }) => {
  const errRows = Object.keys(errors).map((i) => ({
    row: fileData[i],
    errors: errors[i],
  }));

  return (
    <div style={{ marginTop: 20 }}>
      <button onClick={() => exportCSV(fileData)}>Export All</button>

      <button
        disabled={errRows.length === 0}
        onClick={() => exportErrorRows(errRows)}
        style={{ marginLeft: 12 }}
      >
        Export Error Rows
      </button>
    </div>
  );
};

export default ActionsBar;
