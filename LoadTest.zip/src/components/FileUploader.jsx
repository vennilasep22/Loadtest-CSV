import React, { useState } from "react";

const FileUploader = ({ onFilesSelected }) => {
  const [files, setFiles] = useState([]);

  return (
    <div>
      <h3>Select CSV files</h3>
      <input
        type="file"
        accept=".csv"
        multiple
        onChange={(e) => {
          const list = Array.from(e.target.files);
          setFiles(list);
          onFilesSelected(list);
        }}
      />

      {files.length > 0 &&
        files.map((f) => (
          <div key={f.name} style={{ fontSize: 14 }}>
            {f.name}
          </div>
        ))}
    </div>
  );
};

export default FileUploader;
