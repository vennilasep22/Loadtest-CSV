import React from "react";

const MultiFileUploader = ({ onFilesSelected }) => {
  return (
    <div style={{ marginBottom: 20 }}>
      <input
        type="file"
        accept=".csv"
        multiple
        onChange={(e) => onFilesSelected(e.target.files)}
      />
    </div>
  );
};

export default MultiFileUploader;
