{/*import React, { useRef } from "react";
import { useReactTable, getCoreRowModel } from "@tanstack/react-table";
import { useVirtual } from "@tanstack/react-virtual";

const DataTable = ({ rows, headers }) => {
  const columns = headers.map((h) => ({
    accessorKey: h,
    header: h,
    cell: (info) => {
      const val = info.getValue();
      const rowErrors = info.row.original.errors || {};
      const error = rowErrors[h];

      return (
        <div style={{ color: error ? "red" : "black" }}>
          {val}
          {error && <span style={{ marginLeft: 6 }}>⚠️</span>}
        </div>
      );
    },
  }));

  const table = useReactTable({
    data: rows,
    columns,
    getCoreRowModel: getCoreRowModel(),
  });

  const parentRef = useRef(null);

  const rowVirtualizer = useVirtual({
    parentRef,
    size: rows.length,
    overscan: 20,
  });

  return (
    <div
      ref={parentRef}
      style={{
        height: 600,
        overflow: "auto",
        border: "1px solid #ccc",
        marginTop: 20,
      }}
    >
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          {table.getHeaderGroups().map((hg) => (
            <tr key={hg.id}>
              {hg.headers.map((h) => (
                <th
                  key={h.id}
                  style={{
                    padding: 6,
                    border: "1px solid #eee",
                    background: "#f8f8f8",
                  }}
                >
                  {h.renderHeader()}
                </th>
              ))}
            </tr>
          ))}
        </thead>

        <tbody>
          <tr>
            <td colSpan={headers.length} style={{ padding: 0 }}>
              <div
                style={{
                  height: rowVirtualizer.totalSize,
                  position: "relative",
                }}
              >
                {rowVirtualizer.virtualItems.map((item) => {
                  const row = table.getRowModel().rows[item.index];
                  const hasError =
                    Object.keys(row.original.errors || {}).length > 0;

                  return (
                    <div
                      key={item.index}
                      style={{
                        position: "absolute",
                        top: item.start,
                        left: 0,
                        right: 0,
                        display: "flex",
                        background: hasError ? "#ffe6e6" : "white",
                      }}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <div
                          key={cell.id}
                          style={{
                            flex: 1,
                            padding: 6,
                            border: "1px solid #f1f1f1",
                          }}
                        >
                          {cell.renderCell()}
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default DataTable;*/}
import React from "react";

const DataTable = ({ data, errors }) => {
  if (data.length === 0) return <p>No data loaded.</p>;

  const headers = Object.keys(data[0]);

  return (
    <table border="1" cellPadding="6" style={{ marginTop: 20, width: "100%" }}>
      <thead>
        <tr>
          {headers.map((h) => (
            <th key={h}>{h}</th>
          ))}
          <th>Error Summary</th>
        </tr>
      </thead>

      <tbody>
        {data.map((row, index) => (
          <tr
            key={index}
            style={errors[index] ? { background: "#ffe6e6" } : {}}
          >
            {headers.map((h) => (
              <td key={h}>{row[h]}</td>
            ))}

            <td style={{ color: "red" }}>
              {errors[index]
                ? Object.values(errors[index]).join(" | ")
                : ""}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default DataTable;

