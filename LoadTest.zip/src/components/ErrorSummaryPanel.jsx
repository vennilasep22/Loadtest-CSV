{/*import React, { useState } from "react";

const ErrorSummaryPanel = ({ data }) => {
  const [expand, setExpand] = useState(false);

  const errorRows = data.filter(
    (d) => Object.keys(d.errors || {}).length > 0
  );

  const errorCountByField = {};

  errorRows.forEach((row) => {
    Object.keys(row.errors || {}).forEach((field) => {
      errorCountByField[field] = (errorCountByField[field] || 0) + 1;
    });
  });

  return (
    <div
      style={{
        padding: 16,
        border: "1px solid #ddd",
        borderRadius: 8,
        background: "#fafafa",
        marginTop: 20,
        marginBottom: 20,
      }}
    >
      <h3>Error Summary</h3>

      <p>
        <b>Total Rows:</b> {data.length}
      </p>

      <p>
        <b>Rows with Errors:</b> {errorRows.length}
      </p>

      <h4>Error Breakdown</h4>

      <ul>
        {Object.entries(errorCountByField).map(([field, count]) => (
          <li key={field}>
            <b>{field}</b>: {count}
          </li>
        ))}
      </ul>

      <button onClick={() => setExpand(!expand)}>
        {expand ? "Hide Details" : "Show Details"}
      </button>

      {expand && (
        <div
          style={{
            marginTop: 12,
            maxHeight: 300,
            overflow: "auto",
            border: "1px solid #ccc",
          }}
        >
          <table width="100%" border="1" cellPadding="6">
            <thead style={{ background: "#eee" }}>
              <tr>
                <th>Row</th>
                <th>Field</th>
                <th>Error</th>
              </tr>
            </thead>

            <tbody>
              {errorRows.map((row, rowIndex) =>
                Object.entries(row.errors).map(([field, message], i) => (
                  <tr key={rowIndex + "-" + i}>
                    <td>{rowIndex + 1}</td>
                    <td>{field}</td>
                    <td>{message}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ErrorSummaryPanel;*/}
import React from "react";

const ErrorSummaryPanel = ({ errors }) => {
  const count = Object.keys(errors).length;
  if (count === 0) return null;

  const grouped = {};
  Object.values(errors).forEach((errRow) => {
    Object.values(errRow).forEach((msg) => {
      grouped[msg] = (grouped[msg] || 0) + 1;
    });
  });

  return (
    <div style={{ background: "#fff0f0", padding: 10, marginTop: 20 }}>
      <h3>Error Summary ({count} rows)</h3>
      <ul>
        {Object.entries(grouped).map(([msg, total]) => (
          <li key={msg}>
            <b>{msg}</b> — {total} times
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ErrorSummaryPanel;

