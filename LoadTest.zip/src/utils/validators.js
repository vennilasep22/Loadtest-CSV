export const validateRow1 = (row) => {
  const errors = {};

  // Name check
  if (!row.name || row.name.trim() === "") {
    errors.name = "Name is required";
  }

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!row.email || !emailRegex.test(row.email)) {
    errors.email = "Invalid email";
  }

  // Age validation
  const age = Number(row.age);
  if (!age || age < 1 || age > 120) {
    errors.age = "Age must be between 1 and 120";
  }

  // Phone validation
  const phoneRegex = /^[0-9]{10}$/;
  if (!phoneRegex.test(row.phone)) {
    errors.phone = "Invalid phone number";
  }

  return errors;
};
export const validateRow = (row, headers) => {
  const errors = {};

  // -------------------------
  // 1. Validate missing values
  // -------------------------
  headers?.forEach((col) => {
    const value = row[col];

    if (
      value === null ||
      value === undefined ||
      value === "" ||
      (typeof value === "string" && value.trim() === "")
    ) {
      errors[col] = `${col} is required`;
    }
  });

  // If required fields are missing, return early so other validations are not applied
  // (Optional: you can remove this return if you want all validations to run)
  // if (Object.keys(errors).length > 0) return errors;

  // -------------------------
  // 2. Email validation
  // -------------------------
  if (row.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(row.email.trim())) {
      errors.email = "Invalid email format";
    }
  }

  // -------------------------
  // 3. Age validation
  // -------------------------
  if (row.age) {
    const age = Number(row.age);

    if (isNaN(age)) {
      errors.age = "Age must be a number";
    } else if (age < 1 || age > 120) {
      errors.age = "Age must be between 1 and 120";
    }
  }

  // -------------------------
  // 4. Phone validation
  // -------------------------
  if (row.phone) {
    const phoneDigits = row.phone.replace(/\D/g, ""); // keep only numbers

    if (phoneDigits.length !== 10) {
      errors.phone = "Phone number must be 10 digits";
    }
  }

  return errors;
};
