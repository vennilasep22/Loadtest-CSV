import Papa from "papaparse";

export const exportErrorRows = (errData, filename = "error-rows.csv") => {
  const formatted = errData.map((item) => ({
    ...item.row,
    errorSummary: Object.values(item.errors).join(" | "),
  }));

  const csv = Papa.unparse(formatted);

  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
};
