import React, { useEffect, useState } from "react";
// import MultiFileUploader from "./components/MultiFileUploader";
import FileUploader from "./components/FileUploader";
import DataTable from "./components/DataTable";
import ActionsBar from "./components/ActionsBar";
import ErrorSummaryPanel from "./components/ErrorSummaryPanel";

import useMultiFileCSVParser from "./hooks/useMultiFileCSVParser";
// import { exportToCSV } from './utils/./utils/exportCSV';
// import { exportOnlyErrorRows } from "./utils/exportErrorRows";
import { validateRow } from "./utils/validators";

const App = () => {
  const { fileData, headers, error, loading, parseMultipleFiles } =
    useMultiFileCSVParser();
const [rowErrors, setRowErrors] = useState({});
  const handleFiles = (files) => parseMultipleFiles(Array.from(files));

  const validatedData = fileData.map((row) => ({
    ...row,
    errors: validateRow(row),
  }));
// -----------------------------------------
  // Validate rows once parsing is completed
  // -----------------------------------------
  useEffect(() => {
    if (fileData.length === 0) {
      setRowErrors({});
      return;
    }

    const tempErrors = {};

    fileData.forEach((row, index) => {
      const result = validateRow(row, headers);
      if (Object.keys(result).length > 0) {
        tempErrors[index] = result;
      }
    });

    setRowErrors(tempErrors);
  }, [fileData, headers]);
  return (<>
  
   <div style={{ padding: 20 }}>
      <h1>CSV Processor App</h1>

      {/* Upload Files */}
      <FileUploader onFilesSelected={parseMultipleFiles} />

      {/* Show Parsing Status */}
      {loading && <p>Loading… Parsing CSV files…</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}

      {/* Table */}
      {fileData.length > 0 && (
        <>
          <DataTable data={fileData} errors={rowErrors} />

          <ErrorSummaryPanel errors={rowErrors} />

          <ActionsBar fileData={fileData} errors={rowErrors} />
        </>
      )}
    </div></>
    
  );
};

export default App;
