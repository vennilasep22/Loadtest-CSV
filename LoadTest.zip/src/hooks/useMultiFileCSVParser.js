import { useState } from "react";
import Papa from "papaparse";

const useMultiFileCSVParser = () => {
  const [fileData, setFileData] = useState([]);
  const [headers, setHeaders] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const readHeadersOnly = (file) => {
    return new Promise((resolve) => {
      Papa.parse(file, {
        preview: 1,
        header: true,
        skipEmptyLines: true,
        complete: (res) => resolve(Object.keys(res.data[0] || {})),
        error: () => resolve([]),
      });
    });
  };

  const parseFile = (file) => {
    return new Promise((resolve) => {
      const temp = [];

      Papa.parse(file, {
        worker: true,
        header: true,
        skipEmptyLines: true,

        chunk: (chunk) => {
          temp.push(...chunk.data);
        },

        complete: () => resolve(temp),
        error: () => resolve([]),
      });
    });
  };

  const parseMultipleFiles = async (files) => {
    setError("");
    setLoading(true);

    try {
      const firstHeader = await readHeadersOnly(files[0]);

      setHeaders(firstHeader);

      for (let i = 1; i < files.length; i++) {
        const currentHeader = await readHeadersOnly(files[i]);

        if (JSON.stringify(firstHeader) !== JSON.stringify(currentHeader)) {
          setError(`Header mismatch in file: ${files[i].name}`);
          setLoading(false);
          return;
        }
      }

      const allData = [];

      for (const file of files) {
        const parsed = await parseFile(file);
        allData.push(...parsed);
      }

      setFileData(allData);
      setLoading(false);
    } catch {
      setError("Error parsing files");
      setLoading(false);
    }
  };

  return { fileData, headers, error, loading, parseMultipleFiles };
};

export default useMultiFileCSVParser;
