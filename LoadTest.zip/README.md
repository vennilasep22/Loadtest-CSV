# CSV Processor Vite

This project processes large CSV files with PapaParse and displays them with TanStack Table + virtual scrolling.
Features: multi-file header validation, error summary, row highlighting, export-only-error-rows.

## Quick start

1. Install dependencies:
   ```bash
   npm install
